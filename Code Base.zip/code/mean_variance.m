function [holdings] = mean_variance(alpha,cov_matrix,upper_bound,lambda_2,tcost,prev_h,spots,capital)

m = length(alpha);
flag = 0;
one_vector = ones(m,1);
% train svm using cvx
%
upper_bound = upper_bound/sqrt(12);

cvx_begin
    cvx_quiet(true);
    variables h(m)
    minimize(-h'*alpha+ lambda_2*((abs(h-prev_h)./spots')'*tcost'/10000))
    h'*one_vector == 0;
    h'*cov_matrix*h <= square_pos(upper_bound);
    abs(h) <=.2*capital;
cvx_end
if strcmp(cvx_status,'Solved')
    flag = 1;
end
holdings=h;

end

