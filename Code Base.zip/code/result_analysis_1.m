% Interprate results
clc; clear;
load('ccy_proj_results.mat');
capital = 10^6;
% Read in data
vix = result_struct.VIX;
strat_returns = result_struct.strat_returns / capital;
std_returns = result_struct.std_returns / capital;
carry_returns = result_struct.carry_returns / capital;
mom_returns = result_struct.mom_returns / capital;
dates = result_struct.dates;
strat_index = cumsum(strat_returns); strat_index = strat_index + 10^6;
mom_index = cumsum(mom_returns); mom_index = mom_index + 10^6;
std_index = cumsum(std_returns); std_index = std_index + 10^6;
carry_index = cumsum(carry_returns); carry_index = carry_index + 10^6;

% Plot the return against VIX index
figure(100) 
x=dates;
y1=strat_index;
y2=mom_index;
y3=std_index;
y4=carry_index;
y5=vix;
plotyy(x,[y1;y2;y3;y4],x,y5);
legend('Strategy','Momemtum','Volatility','Carry','VIX');


%x2 = result_struct.dates;
%x = datestr(result_struct.dates,'mm/yyyy');
%plot(dates,vix,'yellow'); hold on;
% plot(dates,strat_index); hold on;
% plot(dates,mom_index,'r'); hold on;
% plot(dates,std_index,'g'); hold on;
% plot(dates,carry_index,'black'); hold off;
% legend('VIX','Strategy','Momemtum','Volatility','Carry');
title('Compare the performances for different strategies');
dateaxis('x',2,datestr(731616));
dateaxis('x',2,datestr(731616));
xlabel('Dates');
corr_vix = corrcoef(strat_index,vix)

% Compare the maximum drawdowns for different strategies
max_drawdown_strat = abs(min(strat_returns));
max_drawdown_carry = abs(min(carry_returns));
max_drawdown_mom = abs(min(mom_returns));
max_drawdown_std = abs(min(std_returns));
figure(200)
drawdowns = [max_drawdown_strat max_drawdown_carry max_drawdown_mom max_drawdown_std];
max_drawdown_UBSV10 = 0.318;

hdl = bar(drawdowns,0.8);
grid on;
legend('Strategy','Carry','Momentum','Volatility');
%xticklabel_rotate([],45,Type2);
title('Maximum draw down comparision');
%max_

% Demonstrate alpha
alpha = zeros(3,1);
coeff = regress(strat_index, [ones(length(mom_index),1) mom_index]);
alpha(1) = coeff(1);
coeff = regress(strat_index, [ones(length(carry_index),1) carry_index]);
alpha(2) = coeff(1);
coeff = regress(strat_index, [ones(length(carry_index),1) carry_index]);
alpha(3) = coeff(1);
alpha