function [ind, amount] = max_drawdown(data)
    n = length(data);
    pool = [];
    index = [];
    drawdown = 0;
    for i = 1:n-1
        diff = data(i+1) - data(i);
        if diff <= 0 
            if drawdown == 0
                notional = data(i);
            end
            drawdown = drawdown + abs(diff);
        end
        if diff > 0 && drawdown > 0
            drawdown = drawdown / notional;
            pool = [pool drawdown];
            index = [index i];
            drawdown = 0;
        end
    end
    [amount, i] = max(pool);
    ind = index(i);
end