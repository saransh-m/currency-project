function currency_project()
%load_cvx();
filename = 'processed.csv';
data = file_read(filename,34,2);
VIX=cellfun(@str2num,data{:,end});
%filename = 'ppiprocessed.csv';
%ppi_data = file_read(filename,11,1);
%ppi_dates = datenum(ppi_data{:,1},'mm/dd/yyyy');
%ppi_indexes = 1:1:length(ppi_dates);
rows = length(data{:,1});
cols = length(data);
currencies = {'AUD','GBP','CAD','EUR','JPY','NZD','NOK','SEK','CHF','USD'};
transaction_costs = [1.3 1 1.3 .7 1 4.3 4 3.5 1.3];
flag = [0 0 1 1 1 0 1 1 1 0];
dates = datenum(data{:,1},'mm/dd/yyyy');

for i=1:length(currencies)-1
    if (flag(i))
        spot_rates(:,i) = 1./cellfun(@str2num,data{:,i+1});
        forward_rates(:,i) = 1./(cellfun(@str2num,data{:,length(currencies)+2+i})/10000 + cellfun(@str2num,data{:,i+1}));
    else
        spot_rates(:,i) = cellfun(@str2num,data{:,i+1});
        forward_rates(:,i)= cellfun(@str2num,data{:,length(currencies)+2+i})/10000 + cellfun(@str2num,data{:,i+1});
    end
    ir_differential(:,i) = (spot_rates(:,i)./forward_rates(:,i))-1;
    %ppi_values(:,i) = cellfun(@str2num,ppi_data{:,end}) - cellfun(@str2num,ppi_data{:,i+1});
end

length(data{:,1})

frequency = 22;
months = 12;


start_date=1;
buckets = start_date:frequency:(months+1)*frequency+start_date-1;
inv_periods = floor((length(forward_rates(:,1))-buckets(end))/frequency);

cross_signals = zeros(inv_periods,length(currencies)-1,6);
aggregate_signals = zeros(inv_periods,length(currencies)-1);
carry_signals = zeros(inv_periods,length(currencies)-1);
mom_signals = zeros(inv_periods,length(currencies)-1);
vol_signals = zeros(inv_periods,length(currencies)-1);

return_labels = zeros(inv_periods,length(currencies)-1);
selected_spot_rates = zeros(inv_periods,length(currencies)-1);
return_hist =  zeros(inv_periods,length(currencies)-1);
store_dates = []; signal_dates= [];

capital = 10^6;
types = 6;
strat_pnl = zeros(types,inv_periods,1);
type_list = {'Combination','Momentum','Volatility','Skewness','Boosted Carry','Naive Carry'};
percent_wins = zeros(types,1);
historical_zscores = zeros(3,length(currencies)-1,inv_periods);



for kk=1:inv_periods
    current_date = dates(buckets(end));
    %ppi_index_selection = ppi_indexes(ppi_dates<=current_date);
    %ppi_index_selection(end-months+1:end);
    
    buckets = start_date:frequency:(months+1)*frequency+start_date-1;
    for i=1:length(currencies)-1
        spot_return= (spot_rates(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i)./spot_rates(start_date:frequency:(months)*frequency +start_date-1,i))-1;
        zscore_mom = (spot_return(end)-mean(spot_return))/std(spot_return);
        historical_zscores(1,i,kk)=zscore_mom;
        zscore_mom = -mean(spot_return)/std(spot_return);
        mom_signals(kk,i) = (spot_return(end)-mean(spot_return))/std(spot_return);
        %ppi_vector = ppi_values(ppi_index_selection(end-months+1:end),i);
        %zscore_ppi = (ppi_vector(end)-mean(ppi_vector))/std(ppi_vector);
        
        %ir_diffs = (ir_differential(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i)./ir_differential(start_date:frequency:(months)*frequency+start_date-1,i))-1;
        ir_diffs = (ir_differential(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i)./ir_differential(start_date:frequency:(months)*frequency+start_date-1,i))-1;
        zscore_carry = (ir_diffs(end)-mean(ir_diffs))/std(ir_diffs);
        ir_diff_signal = ir_differential(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i);
        carry_signals(kk,i) = (ir_diff_signal(end)-mean(ir_diff_signal))/std(ir_diff_signal);
        daily_spot_returns = spot_rates(buckets(1)+1:buckets(end),i)./spot_rates(buckets(1):buckets(end)-1,i);
        std_store = zeros(length(buckets)-1,1);
        skew_store = zeros(length(buckets)-1,1);
        
        for j=2:length(buckets)
            std_store(j-1) = std(daily_spot_returns(buckets(j-1)-(kk-1)*frequency:buckets(j)-1-(kk-1)*frequency));
            skew_store(j-1) = skewness(daily_spot_returns(buckets(j-1)-(kk-1)*frequency:buckets(j)-1-(kk-1)*frequency));
        end
        zscore_std = (std_store(end)-mean(std_store))/std(std_store);
        vol_signals(kk,i) = zscore_std;
        historical_zscores(2,i,kk)=zscore_std;
        zscore_skew = (skew_store(end)-mean(skew_store))/std(skew_store);
        historical_zscores(3,i,kk)=zscore_skew;
        
        cross_signals(kk,i,1) = -zscore_std*zscore_carry;
        
        cross_signals(kk,i,2) = zscore_std;
        cross_signals(kk,i,3) = zscore_skew;
        cross_signals(kk,i,4) = zscore_mom;
        cross_signals(kk,i,5) = -zscore_mom*zscore_carry;
        cross_signals(kk,i,6) = zscore_carry;
    end
    
    [mom_values,indexes] = sort(mom_signals(kk,:));
    mom_signals(kk,indexes(1:3)) = -1;
    mom_signals(kk,indexes(end-2:end)) = 1;
    mom_signals(kk,indexes(4:6)) = 0;
    
    [vol_values,indexes] = sort(vol_signals(kk,:));
    vol_signals(kk,indexes(1:3))=-1;
    vol_signals(kk,indexes(end-2:end))=1;
    vol_signals(kk,indexes(4:6)) = 0;
    
    [carry_values,indexes] = sort(carry_signals(kk,:));
    carry_signals(kk,indexes(1:3))=-1;
    carry_signals(kk,indexes(end-2:end))=1;
    carry_signals(kk,indexes(4:6)) = 0;
    
    %carry_signals
    %vol_signals
    
    %more interest rate differential
    cross_signals(kk,:,1)= (cross_signals(kk,:,1)-mean(cross_signals(kk,:,1)))/std(cross_signals(kk,:,1));
    
    cross_signals(kk,:,2)= (cross_signals(kk,:,2)-mean(cross_signals(kk,:,2)))/std(cross_signals(kk,:,2));
    cross_signals(kk,:,3)= -(cross_signals(kk,:,3)-mean(cross_signals(kk,:,3)))/std(cross_signals(kk,:,3));
    cross_signals(kk,:,4)= (cross_signals(kk,:,4)-mean(cross_signals(kk,:,4)))/std(cross_signals(kk,:,4));
    cross_signals(kk,:,5)= (cross_signals(kk,:,5)-mean(cross_signals(kk,:,5)))/std(cross_signals(kk,:,5));
    cross_signals(kk,:,6)= (cross_signals(kk,:,6)-mean(cross_signals(kk,:,6)))/std(cross_signals(kk,:,6));
    
    
    start_date = buckets(2);
    aggregate_signal = zeros(length(currencies)-1,1);
    aggregate_signal_mom = zeros(length(currencies)-1,1);
    aggregate_signal_std = zeros(length(currencies)-1,1);
    aggregate_signal_skew = zeros(length(currencies)-1,1);
    aggregate_signal_carry = zeros(length(currencies)-1,1);
    aggregate_signal_naive_carry = zeros(length(currencies)-1,1);
    for j=1:length(currencies)-1
        aggregate_signal(j,1)=sum(cross_signals(kk,j,1:end-1));
        aggregate_signal_mom(j,1) = cross_signals(kk,j,4);
        aggregate_signal_std(j,1) = cross_signals(kk,j,2);
        aggregate_signal_skew(j,1) = cross_signals(kk,j,3);
        aggregate_signal_carry(j,1) = cross_signals(kk,j,1) + cross_signals(kk,j,5);
        aggregate_signal_naive_carry(j,1) = cross_signals(kk,j,6);
    end
    
    aggregate_signal(:,1) = (aggregate_signal(:,1)-mean(aggregate_signal(:,1)))/std(aggregate_signal(:,1));
    aggregate_signal_mom(:,1) = (aggregate_signal_mom(:,1)-mean(aggregate_signal_mom(:,1)))/std(aggregate_signal_mom(:,1));
    aggregate_signal_std(:,1) = (aggregate_signal_std(:,1)-mean(aggregate_signal_std(:,1)))/std(aggregate_signal_std(:,1));
    aggregate_signal_skew(:,1) = (aggregate_signal_skew(:,1)-mean(aggregate_signal_skew(:,1)))/std(aggregate_signal_skew(:,1));
    aggregate_signal_carry(:,1) = (aggregate_signal_carry(:,1)-mean(aggregate_signal_carry(:,1)))/std(aggregate_signal_carry(:,1));
    aggregate_signal_naive_carry(:,1) = (aggregate_signal_naive_carry(:,1)-mean(aggregate_signal_naive_carry(:,1)))/std(aggregate_signal_naive_carry(:,1));
    
    aggregate_signals(kk,:)= aggregate_signal(:,1);
    
    cap_alloc = aggregate_signal(:,1)*capital;
    strat_pnl(1,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_mom(:,1)*capital;
    strat_pnl(2,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_std(:,1)*capital;
    strat_pnl(3,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_skew(:,1)*capital;
    strat_pnl(4,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_carry(:,1)*capital;
    strat_pnl(5,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_naive_carry(:,1)*capital;
    strat_pnl(6,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    
    
    return_labels(kk,:)=sign(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1);
    return_hist(kk,:)=spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1;
    selected_spot_rates(kk,:)=spot_rates(buckets(end),:);
    percent_wins = percent_wins + (strat_pnl(:,kk)>0);
    store_dates(end+1) = dates(buckets(end)+frequency,1);
    signal_dates(end+1) = dates(buckets(end),1);
end
val_1 = (1:inv_periods)';
save('contrarian_evidence.mat','historical_zscores');

%[mdd,mdd1,mdd2] = MAXDRAWDOWN(strat_pnl(1,:));

for i=1:types
    results(i).IR = (mean(strat_pnl(i,:))/std(strat_pnl(i,:)))*sqrt(months);
    results(i).SKEW = skewness(strat_pnl(i,:));
    results(i).KURTOSIS = kurtosis(strat_pnl(i,:));
    results(i).RETURN = (mean(strat_pnl(i,:)/(2*capital))*months)*100;
    results(i).VOLATILTY = (std(strat_pnl(i,:)/(2*capital))*sqrt(months))*100;
    results(i).IC = (percent_wins(i)/inv_periods)*2-1;
    results(i).type = type_list{i};
    results(i).monthly_pnl = strat_pnl(i,:);
    results(i).dates = store_dates;
end

results(1)
return_labels;
aggregate_signals;

period = 1:1:length(strat_pnl);
figure(1);
plot(period,cumsum(strat_pnl(1,:)),period,cumsum(strat_pnl(2,:)),period,cumsum(strat_pnl(3,:)),period,cumsum(strat_pnl(4,:)),period,cumsum(strat_pnl(5,:)),period,cumsum(strat_pnl(6,:)));


figure(2);
hist(strat_pnl(1,:));

%SVM boost


removal_results=[];
%for kkk=1:length(currencies)-1
period_t = 24;
lookback = 24;
svm_signals = zeros(length(currencies)-1,1);
svm_pnl = zeros(5,1);
mom_pnl = [];
std_pnl = [];
carry_pnl = [];
orig_svm_pnl = zeros(5,1);
new_period = 1+period_t:1:inv_periods;
percent_wins =0;
w = zeros(length(currencies)-1,2,1);
period_by_period = 12;
prev_signals = zeros(length(currencies)-1,1);


turnover =0;
yearly_IRs=[];
yearly_returns=[];
yearly_stds=[];
inv_periods
losses = zeros(length(currencies)-1,1);
prev_losses = losses;
result_struct = [];
main_counter = 1;
flag_thorny = 0;


main_counter = 1;
loss_period = 6;
loss_count = 1;
param = 1;
kkk=1;
    %for kkk=1:1
for start_j=1:inv_periods-period_t
    
    for i=1:length(currencies)-1
        if (mod(start_j-1,12)==0)
            ys = return_labels(start_j:start_j+period_t-1,1);
            xs = aggregate_signals(start_j:start_j+period_t-1,i);
            w_1 = SVM(xs,ys,100);
            w(i,:,:) = w_1;
        end
        x_new = vertcat(aggregate_signals(start_j+period_t,i),1);
        
        svm_signals(i) = -w(i,:,:)*x_new;
        if (mod(start_j-1,12)==0)
            svm_signals(i) = -w(i,:,:)*x_new*abs(aggregate_signals(start_j+period_t,i,1));
        else
            svm_signals(i) = aggregate_signals(start_j+period_t,i,1)*abs(w(i,:,:)*x_new);
        end
    end
    
    if (start_j+period_t>lookback)
        %start_j+period_t
        %then trade
        hist_rets = return_hist((start_j+period_t - lookback):(start_j+period_t-1),:);
        cov_matrix = cov(hist_rets);
        
        strat_svm_signals = (svm_signals - mean(svm_signals))/std(svm_signals);
        svm_signals = strat_svm_signals;
        if (mod(loss_count,loss_period)==0)
            prev_losses = losses;
            losses = 0;
        end
        if ~(prev_losses==0) & (~flag_thorny)
            
            [loss_values,indexes] = sort(prev_losses);
            svm_signals(indexes(1:2))=0;
        end
        %svm_signals(kkk) = 0;
        [holdings] = mean_variance(sign(svm_signals),cov_matrix,param,0,transaction_costs,prev_signals,selected_spot_rates(start_j+period_t,:),capital);    
        %[holdings_paper] = mean_variance(sign(strat_svm_signals),cov_matrix,.10,2,transaction_costs,prev_signals,selected_spot_rates(start_j+period_t,:),capital);    
            
        
        %holdings = svm_signals;
        cap_alloc = holdings*capital;
        prev_cap_alloc = prev_signals*capital;
        tcost = (abs(cap_alloc - prev_cap_alloc)./(selected_spot_rates(start_j+period_t,:)'))'*transaction_costs'/10000;
        
        turnover = (turnover*(start_j-1) + (min(sum(max(cap_alloc - prev_cap_alloc ,0)),sum(max(prev_cap_alloc - cap_alloc ,0)))/(2*capital)))/start_j;
        %svm_pnl(start_j) = cap_alloc'*return_hist(start_j+period_t,:)' - tcost;
        svm_pnl(start_j) = cap_alloc'*return_hist(start_j+period_t,:)';
        
        
        mom_pnl(start_j) = (mom_signals(start_j + period_t,:)*capital)*return_hist(start_j+period_t,:)';
        std_pnl(start_j) = (vol_signals(start_j + period_t,:)*capital)*return_hist(start_j+period_t,:)';
        carry_pnl(start_j) = (carry_signals(start_j + period_t,:)*capital)*return_hist(start_j+period_t,:)';
        
        losses = losses + holdings.*return_hist(start_j+period_t,:)';
        percent_wins = percent_wins + (svm_pnl(start_j)>0);
        prev_signals = holdings;
        if (mod(start_j+period_t,period_by_period)==0)
            datestr(store_dates(start_j+period_t),'dd/mm/yyyy')
            yearly_IRs(end+1) =(mean(svm_pnl(end-months+1:end))/std(svm_pnl(end-months+1:end)))*sqrt(months);
            yearly_returns(end+1) =(mean(svm_pnl(end-months+1:end)/(2*capital))*months)*100;
            yearly_stds(end+1) =(std(svm_pnl(end-months+1:end)/(2*capital))*sqrt(months))*100;
        end
        loss_count = loss_count + 1;
        res_strat_returns(main_counter) = svm_pnl(start_j);
        res_holdings(main_counter,:)= holdings;
        res_dates(main_counter) = store_dates(start_j+period_t);
        res_VIX(main_counter) = VIX((start_j+period_t)*frequency);
        res_ccy_return(main_counter,:) = holdings.*return_hist(start_j+period_t,:)';
        res_spot_return(main_counter,:) = return_hist(start_j+period_t,:);
        res_carry_returns(main_counter) = carry_pnl(start_j);
        res_std_returns(main_counter) = std_pnl(start_j);
        res_mom_returns(main_counter) = mom_pnl(start_j);
        main_counter = main_counter + 1;
        removal_results.strat_return(kkk,main_counter) = svm_pnl(start_j);
        removal_results.dates(kkk,main_counter) = store_dates(start_j+period_t);
        
        
    end
    
end
%end

insample_returns = res_strat_returns(res_dates < datenum('20110101','yyyymmdd'));
outsample_returns = res_strat_returns(res_dates >= datenum('20110101','yyyymmdd'));
insample_IR = (mean(insample_returns)/std(insample_returns))*sqrt(months);
outsample_IR = (mean(outsample_returns)/std(outsample_returns))*sqrt(months);
insample_return = (mean(insample_returns/(2*capital))*months)*100;
outsample_return = (mean(outsample_returns/(2*capital))*months)*100;
insample_vol = (std(insample_returns/(2*capital))*sqrt(months))*100;
outsample_vol = (std(outsample_returns/(2*capital))*sqrt(months))*100;

insample_IR
outsample_IR
insample_return
outsample_return
insample_vol
outsample_vol
pause;

svm_result.IR = (mean(svm_pnl)/std(svm_pnl))*sqrt(months);
svm_result.SKEW = skewness(svm_pnl);
svm_result.KURTOSIS = kurtosis(svm_pnl);
svm_result.RETURN = (mean(svm_pnl/(2*capital))*months)*100;
svm_result.VOLATILTY = (std(svm_pnl/(2*capital))*sqrt(months))*100;


res_strat_returns
save('removal_results.mat','removal_results');
pause;
result_struct.strat_returns = res_strat_returns;
result_struct.mom_returns = res_mom_returns;
result_struct.std_returns = res_std_returns;
result_struct.carry_returns = res_carry_returns;
result_struct.holdings = res_holdings';
result_struct.dates = res_dates;
result_struct.VIX = res_VIX;
result_struct.spot_return = res_spot_return;
result_struct.ccy_return = res_ccy_return';
result_struct.out_of_sample = '12/31/2010';
save('ccy_proj_results.mat','result_struct');
result_struct

yearly_IRs
yearly_returns
yearly_stds

turnover*100
figure(3);
yearly_IRs'
plot(new_period,cumsum(svm_pnl),'r',new_period,cumsum(strat_pnl(1,new_period)),'g');
figure(4);
plotyy(new_period,VIX(new_period*frequency),new_period,cumsum(svm_pnl));
svm_result.yearly_results = [yearly_IRs' yearly_returns' yearly_stds'];

[yearly_IRs' yearly_returns' yearly_stds']
svm_result.IR = (mean(svm_pnl)/std(svm_pnl))*sqrt(months);
svm_result.SKEW = skewness(svm_pnl);
svm_result.KURTOSIS = kurtosis(svm_pnl);
svm_result.RETURN = (mean(svm_pnl/(2*capital))*months)*100;
svm_result.VOLATILTY = (std(svm_pnl/(2*capital))*sqrt(months))*100;
svm_result.IC = (percent_wins/length(new_period))*2-1;
svm_result.type = 'SVM Boost';
svm_result.monthly_pnl = svm_pnl';
svm_result.dates = store_dates(new_period);

svm_result
(mean(strat_pnl(1,new_period))/std(strat_pnl(1,new_period)))*sqrt(months)
skewness(strat_pnl(1,new_period))
kurtosis(strat_pnl(1,new_period))
(mean(strat_pnl(1,new_period)/(2*capital))*months)*100
(std(strat_pnl(1,new_period)/(2*capital))*sqrt(months))*100

save('signal.mat','results');
save('final_signal.mat','svm_result');
%results(1)
end

function [data] = file_read(file,cols,hL)
    fid = fopen(file);
    pattern = '';
    number_cols = cols;
    for i=1:number_cols
        pattern = ['%s' pattern];
    end
    
    [data] = textscan(fid,pattern,'delimiter',',','headerLines',hL);
end


