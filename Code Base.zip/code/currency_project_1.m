function currency_project()
%load_cvx();
filename = 'processed.csv';
data = file_read(filename,33,2);
%filename = 'ppiprocessed.csv';
%ppi_data = file_read(filename,11,1);
%ppi_dates = datenum(ppi_data{:,1},'mm/dd/yyyy');
%ppi_indexes = 1:1:length(ppi_dates);
rows = length(data{:,1});
cols = length(data);
currencies = {'AUD','GBP','CAD','EUR','JPY','NZD','NOK','SEK','CHF','USD'};
transaction_costs = [1.3 1 1.3 .7 1 4.3 4 3.5 1.3];
flag = [0 0 1 1 1 0 1 1 1 0];
dates = datenum(data{:,1},'mm/dd/yyyy');

for i=1:length(currencies)-1
    if (flag(i))
        spot_rates(:,i) = 1./cellfun(@str2num,data{:,i+1});
        forward_rates(:,i) = 1./(cellfun(@str2num,data{:,length(currencies)+2+i})/10000 + cellfun(@str2num,data{:,i+1}));
    else
        spot_rates(:,i) = cellfun(@str2num,data{:,i+1});
        forward_rates(:,i)= cellfun(@str2num,data{:,length(currencies)+2+i})/10000 + cellfun(@str2num,data{:,i+1});
    end
    ir_differential(:,i) = (spot_rates(:,i)./forward_rates(:,i))-1;
    %ppi_values(:,i) = cellfun(@str2num,ppi_data{:,end}) - cellfun(@str2num,ppi_data{:,i+1});
end

length(data{:,1})

frequency = 22;
months = 12;


start_date=1;
buckets = start_date:frequency:(months+1)*frequency+start_date-1;
inv_periods = floor((length(forward_rates(:,1))-buckets(end))/frequency);

cross_signals = zeros(inv_periods,length(currencies)-1,6);
aggregate_signals = zeros(inv_periods,length(currencies)-1);
return_labels = zeros(inv_periods,length(currencies)-1);
selected_spot_rates = zeros(inv_periods,length(currencies)-1);
return_hist =  zeros(inv_periods,length(currencies)-1);
store_dates = []; signal_dates= [];

capital = 10^6;
types = 6;
strat_pnl = zeros(types,inv_periods,1);
type_list = {'Combination','Momentum','Volatility','Skewness','Boosted Carry','Naive Carry'};
percent_wins = zeros(types,1);
historical_zscores = zeros(3,length(currencies)-1,inv_periods);


for kk=1:inv_periods
    current_date = dates(buckets(end));
    %ppi_index_selection = ppi_indexes(ppi_dates<=current_date);
    %ppi_index_selection(end-months+1:end);
    
    buckets = start_date:frequency:(months+1)*frequency+start_date-1;
    for i=1:length(currencies)-1
        spot_return= (spot_rates(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i)./spot_rates(start_date:frequency:(months)*frequency +start_date-1,i))-1;
        zscore_mom = (spot_return(end)-mean(spot_return))/std(spot_return);
        historical_zscores(1,i,kk)=zscore_mom;
        zscore_mom = -mean(spot_return)/std(spot_return);
        
        %ppi_vector = ppi_values(ppi_index_selection(end-months+1:end),i);
        %zscore_ppi = (ppi_vector(end)-mean(ppi_vector))/std(ppi_vector);
        
        ir_diffs = (ir_differential(start_date+frequency:frequency:(months+1)*frequency+start_date-1,i)./ir_differential(start_date:frequency:(months)*frequency+start_date-1,i))-1;
        zscore_carry = (ir_diffs(end)-mean(ir_diffs))/std(ir_diffs);

        daily_spot_returns = spot_rates(buckets(1)+1:buckets(end),i)./spot_rates(buckets(1):buckets(end)-1,i);
        std_store = zeros(length(buckets)-1,1);
        skew_store = zeros(length(buckets)-1,1);
        
        for j=2:length(buckets)
            std_store(j-1) = std(daily_spot_returns(buckets(j-1)-(kk-1)*frequency:buckets(j)-1-(kk-1)*frequency));
            skew_store(j-1) = skewness(daily_spot_returns(buckets(j-1)-(kk-1)*frequency:buckets(j)-1-(kk-1)*frequency));
        end
        zscore_std = (std_store(end)-mean(std_store))/std(std_store);
        historical_zscores(2,i,kk)=zscore_std;
        zscore_skew = (skew_store(end)-mean(skew_store))/std(skew_store);
        historical_zscores(3,i,kk)=zscore_skew;
        
        cross_signals(kk,i,1) = -zscore_std*zscore_carry;
        
        cross_signals(kk,i,2) = zscore_std;
        cross_signals(kk,i,3) = zscore_skew;
        cross_signals(kk,i,4) = zscore_mom;
        cross_signals(kk,i,5) = -zscore_mom*zscore_carry;
        cross_signals(kk,i,6) = zscore_carry;
    end
    
    %more interest rate differential
    cross_signals(kk,:,1)= (cross_signals(kk,:,1)-mean(cross_signals(kk,:,1)))/std(cross_signals(kk,:,1));
    
    cross_signals(kk,:,2)= (cross_signals(kk,:,2)-mean(cross_signals(kk,:,2)))/std(cross_signals(kk,:,2));
    cross_signals(kk,:,3)= -(cross_signals(kk,:,3)-mean(cross_signals(kk,:,3)))/std(cross_signals(kk,:,3));
    cross_signals(kk,:,4)= (cross_signals(kk,:,4)-mean(cross_signals(kk,:,4)))/std(cross_signals(kk,:,4));
    cross_signals(kk,:,5)= (cross_signals(kk,:,5)-mean(cross_signals(kk,:,5)))/std(cross_signals(kk,:,5));
    cross_signals(kk,:,6)= (cross_signals(kk,:,6)-mean(cross_signals(kk,:,6)))/std(cross_signals(kk,:,6));
    
    
    start_date = buckets(2);
    aggregate_signal = zeros(length(currencies)-1,1);
    aggregate_signal_mom = zeros(length(currencies)-1,1);
    aggregate_signal_std = zeros(length(currencies)-1,1);
    aggregate_signal_skew = zeros(length(currencies)-1,1);
    aggregate_signal_carry = zeros(length(currencies)-1,1);
    aggregate_signal_naive_carry = zeros(length(currencies)-1,1);
    for j=1:length(currencies)-1
        aggregate_signal(j,1)=sum(cross_signals(kk,j,1:end-1));
        aggregate_signal_mom(j,1) = cross_signals(kk,j,4);
        aggregate_signal_std(j,1) = cross_signals(kk,j,2);
        aggregate_signal_skew(j,1) = cross_signals(kk,j,3);
        aggregate_signal_carry(j,1) = cross_signals(kk,j,1) + cross_signals(kk,j,5);
        aggregate_signal_naive_carry(j,1) = cross_signals(kk,j,6);
    end
    
    aggregate_signal(:,1) = (aggregate_signal(:,1)-mean(aggregate_signal(:,1)))/std(aggregate_signal(:,1));
    aggregate_signal_mom(:,1) = (aggregate_signal_mom(:,1)-mean(aggregate_signal_mom(:,1)))/std(aggregate_signal_mom(:,1));
    aggregate_signal_std(:,1) = (aggregate_signal_std(:,1)-mean(aggregate_signal_std(:,1)))/std(aggregate_signal_std(:,1));
    aggregate_signal_skew(:,1) = (aggregate_signal_skew(:,1)-mean(aggregate_signal_skew(:,1)))/std(aggregate_signal_skew(:,1));
    aggregate_signal_carry(:,1) = (aggregate_signal_carry(:,1)-mean(aggregate_signal_carry(:,1)))/std(aggregate_signal_carry(:,1));
    aggregate_signal_naive_carry(:,1) = (aggregate_signal_naive_carry(:,1)-mean(aggregate_signal_naive_carry(:,1)))/std(aggregate_signal_naive_carry(:,1));
    
    aggregate_signals(kk,:)= aggregate_signal(:,1);
    
    cap_alloc = aggregate_signal(:,1)*capital;
    strat_pnl(1,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_mom(:,1)*capital;
    strat_pnl(2,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_std(:,1)*capital;
    strat_pnl(3,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_skew(:,1)*capital;
    strat_pnl(4,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_carry(:,1)*capital;
    strat_pnl(5,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    cap_alloc = aggregate_signal_naive_carry(:,1)*capital;
    strat_pnl(6,kk) = cap_alloc'*(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1)';
    
    
    return_labels(kk,:)=sign(spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1);
    return_hist(kk,:)=spot_rates(buckets(end)+frequency,:)./spot_rates(buckets(end),:)-1;
    selected_spot_rates(kk,:)=spot_rates(buckets(end),:);
    percent_wins = percent_wins + (strat_pnl(:,kk)>0);
    
    store_dates(end+1) = dates(buckets(end)+frequency,1);
    signal_dates(end+1) = dates(buckets(end),1);
end
val_1 = (1:inv_periods)';
save('contrarian_evidence.mat','historical_zscores');

%[mdd,mdd1,mdd2] = MAXDRAWDOWN(strat_pnl(1,:));

for i=1:types
    results(i).IR = (mean(strat_pnl(i,:))/std(strat_pnl(i,:)))*sqrt(months);
    results(i).SKEW = skewness(strat_pnl(i,:));
    results(i).KURTOSIS = kurtosis(strat_pnl(i,:));
    results(i).RETURN = (mean(strat_pnl(i,:)/(2*capital))*months)*100;
    results(i).VOLATILTY = (std(strat_pnl(i,:)/(2*capital))*sqrt(months))*100;
    results(i).IC = (percent_wins(i)/inv_periods)*2-1;
    results(i).type = type_list{i};
    results(i).monthly_pnl = strat_pnl(i,:);
    results(i).dates = store_dates;
end

results(1)
return_labels;
aggregate_signals;

period = 1:1:length(strat_pnl);
figure(1);
plot(period,cumsum(strat_pnl(1,:)),period,cumsum(strat_pnl(2,:)),period,cumsum(strat_pnl(3,:)),period,cumsum(strat_pnl(4,:)),period,cumsum(strat_pnl(5,:)),period,cumsum(strat_pnl(6,:)));


figure(2);
hist(strat_pnl(1,:));

%SVM boost




period_t = 24;
lookback = 24;
svm_signals = zeros(length(currencies)-1,1);
svm_pnl = zeros(5,1);
orig_svm_pnl = zeros(5,1);
new_period = 1+period_t:1:inv_periods;
percent_wins =0;
w = zeros(length(currencies)-1,2,1);
period_by_period = 12;
prev_signals = zeros(length(currencies)-1,1);


turnover =0;
yearly_IRs=[];
yearly_returns=[];
yearly_stds=[];
inv_periods
for start_j=1:inv_periods-period_t
    
    for i=1:length(currencies)-1
        if (mod(start_j-1,12)==0)
            ys = return_labels(start_j:start_j+period_t-1,1);
            xs = aggregate_signals(start_j:start_j+period_t-1,i);
            w_1 = SVM(xs,ys,100);
            w(i,:,:) = w_1;
        end
        x_new = vertcat(aggregate_signals(start_j+period_t,i),1);
        
        svm_signals(i) = -w(i,:,:)*x_new;
        if (mod(start_j-1,12)==0)
            svm_signals(i) = -w(i,:,:)*x_new*abs(aggregate_signals(start_j+period_t,i,1));
        else
            svm_signals(i) = aggregate_signals(start_j+period_t,i,1)*abs(w(i,:,:)*x_new);
        end
    end
    
    if (start_j+period_t>lookback)
        start_j+period_t
        %then trade
        hist_rets = return_hist((start_j+period_t - lookback):(start_j+period_t-1),:);
        cov_matrix = cov(hist_rets);
        svm_signals = (svm_signals - mean(svm_signals))/std(svm_signals);
        [holdings] = mean_variance(svm_signals,cov_matrix,.5,2,transaction_costs,prev_signals,selected_spot_rates(start_j+period_t,:));
        %holdings = svm_signals;
        cap_alloc = holdings*capital;
        prev_cap_alloc = prev_signals*capital;
        tcost = (abs(cap_alloc - prev_cap_alloc)./(selected_spot_rates(start_j+period_t,:)'))'*transaction_costs'/10000;
        
        turnover = (turnover*(start_j-1) + (min(sum(max(cap_alloc - prev_cap_alloc ,0)),sum(max(prev_cap_alloc - cap_alloc ,0)))/(2*capital)))/start_j;
        %svm_pnl(start_j) = cap_alloc'*return_hist(start_j+period_t,:)' - tcost;
        svm_pnl(start_j) = cap_alloc'*return_hist(start_j+period_t,:)';
        percent_wins = percent_wins + (svm_pnl(start_j)>0);
        prev_signals = holdings;
        if (mod(start_j,period_by_period)==0)
            yearly_IRs(end+1) =(mean(svm_pnl(end-months+1:end))/std(svm_pnl(end-months+1:end)))*sqrt(months);
            yearly_returns(end+1) =(mean(svm_pnl(end-months+1:end)/(2*capital))*months)*100;
            yearly_stds(end+1) =(std(svm_pnl(end-months+1:end)/(2*capital))*sqrt(months))*100;
        end
    end
end
yearly_IRs
yearly_returns
yearly_stds
pause;
turnover*100
figure(3);
yearly_IRs'
plot(new_period,cumsum(svm_pnl),'r',new_period,cumsum(strat_pnl(1,new_period)),'g');
svm_result.yearly_results = [yearly_IRs' yearly_returns' yearly_stds'];

[yearly_IRs' yearly_returns' yearly_stds']
svm_result.IR = (mean(svm_pnl)/std(svm_pnl))*sqrt(months);
svm_result.SKEW = skewness(svm_pnl);
svm_result.KURTOSIS = kurtosis(svm_pnl);
svm_result.RETURN = (mean(svm_pnl/(2*capital))*months)*100;
svm_result.VOLATILTY = (std(svm_pnl/(2*capital))*sqrt(months))*100;
svm_result.IC = (percent_wins/length(new_period))*2-1;
svm_result.type = 'SVM Boost';
svm_result.monthly_pnl = svm_pnl';
svm_result.dates = store_dates(new_period);

svm_result
(mean(strat_pnl(1,new_period))/std(strat_pnl(1,new_period)))*sqrt(months)
skewness(strat_pnl(1,new_period))
kurtosis(strat_pnl(1,new_period))
(mean(strat_pnl(1,new_period)/(2*capital))*months)*100
(std(strat_pnl(1,new_period)/(2*capital))*sqrt(months))*100

save('signal.mat','results');
save('final_signal.mat','svm_result');
%results(1)
end

function [data] = file_read(file,cols,hL)
    fid = fopen(file);
    pattern = '';
    number_cols = cols;
    for i=1:number_cols
        pattern = ['%s' pattern];
    end
    
    [data] = textscan(fid,pattern,'delimiter',',','headerLines',hL);
end


