clc;clear;close all;
thorny = load('thorny.mat');
thorny = thorny.svm_result;
smooth = load('smooth.mat');
smooth = smooth.svm_result;

smoothPnLs = smooth.monthly_pnl/1000000;
smoothPnLs = smoothPnLs';
thornyPnLs = thorny.monthly_pnl/1000000;
thornyPnLs = thornyPnLs';
Dates = smooth.dates;
Dates = Dates';
CumPnLs =[cumsum(smoothPnLs) cumsum(thornyPnLs)];

figure(1);
hdl = plot(repmat(Dates,1,2), CumPnLs);
xlim([Dates(1), Dates(end)+100]);
set(hdl,'LineWidth',2)
grid on;
dateaxis('x',2,datestr(Dates(1)));
xticklabel_rotate([],45);
legend('stop loss','no stop loss','location','best');
xlabel('Date');ylabel('$(MM)');
title('Cumulative P&L with stop loss');