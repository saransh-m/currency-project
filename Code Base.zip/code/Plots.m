clc;clear;close all;
load('signal.mat');
load('final_signal.mat');
load('contrarian_evidence.mat');
load('ccy_proj_results.mat');
load('thorny.mat');
load('smooth.mat');
%%
NumTypes = 6;
NumMonths = 115;
PnLs = zeros(NumMonths,NumTypes);
CumPnLs = zeros(NumMonths,NumTypes);
AnnualCVA = zeros(NumMonths,NumTypes);
Types = cell(NumTypes,1);
Skewness = zeros(NumTypes,1);
Vols = zeros(NumTypes,1);
Returns = zeros(NumTypes,1);
IRs= zeros(NumTypes,1);


for i=1:NumTypes
   PnLs(:,i) = results(i).monthly_pnl/1000000;
   AnnualCVA(:,i) =  log(1 + PnLs(:,i)/12);
   Types(i) = {results(i).type};
   Returns(i) = results(i).RETURN/100;
   Vols(i) = results(i).VOLATILTY/100;   
   IRs(i) =  results(i).IR;  
   Skewness(i) = results(i).SKEW;  
end
Dates = results(i).dates;
Dates = Dates';
CumPnLs =cumsum(PnLs);
AnnualCVA=cumsum(AnnualCVA);


PnLs2 = zeros(91,2);
CumPnLs2 = zeros(91,2);
PnLs2(:,1) = svm_result.monthly_pnl/1000000;
CumPnLs2(:,1) = cumsum(PnLs2(:,1));
Type2(1,1) = {'Jan Effect'};
Returns2(1) = svm_result.RETURN/100;
Vols2(1,1) = svm_result.VOLATILTY/100;   
IRs2(1,1) =  svm_result.IR;  
Skewness2(1,1) = svm_result.SKEW; 
PnLs2(:,2) = PnLs(25:end,1);
CumPnLs2(:,2) =CumPnLs(1);
Type2(2,1) = Types(1);
Returns2(2,1) = Returns(1);
Vols2(2,1) = Vols(1);   
IRs2(2,1) =  IRs(1);  
Skewness2(2,1) =Skewness(1); 

figure(1);
hdl = plot(repmat(Dates,1,NumTypes), CumPnLs);
set(hdl,'LineWidth',2)
grid on;
dateaxis('x',2,datestr(731616));
xticklabel_rotate([],45);
for i=1:length(Types)
   tpy = Types(i);
   txt = sprintf('%s\n (CVA=%.2f%%)',tpy{1},AnnualCVA(end,i)*100);
   Types(i)= {txt};
end
gridLegend(hdl,2,Types,'location','north','Fontsize',9,'Box','off','XColor',[1 1 1],'YColor',[1 1 1]);
xlabel('Date');ylabel('$(MM)');
title('Cumulative P&L');

figure(2);
hdl=bar([IRs Returns Skewness Vols],0.9);
grid on;
%gridLegend(hdl,2,{'Sharp Ratio','Return','Skewness','Vol'},'location','Best','Fontsize',9,'Box','off','XColor',[1 1 1],'YColor',[1 1 1]);
legend('Sharp Ratio','Return','Skewness','Vol');
%set(gca,'XTickLabel',Types);
xticklabel_rotate([],45,Types);
title('Signal comparison');

figure(3);
IRs2(2) = 0.88
Returns2(2) = .086
Skewness2(2) = .0915
Vols2(2) = .097

hdl=bar([IRs2 Returns2 Skewness2 Vols2],0.8);
grid on;
legend('Sharp Ratio','Return','Skewness','Vol');
%set(gca,'XTickLabel',Types);
xticklabel_rotate([],45,Type2);
title('Signal w/ Jan. VS  combined signal w/o Jan.');

%%
figure(4);
xmin = Dates(1);
xmax = Dates(end)+100;
data = squeeze(historical_zscores(1,:,:));
data = data';
plot(Dates,data(:,2),Dates,data(:,4),Dates,data(:,5));
title('Mean reversion of momentum');
grid on;
xlim([xmin xmax]);
dateaxis('x',2,'02/04/03');
xlabel('Momentum cross-sectional Z-score');ylabel('value');
legend('GPB/USD','EUR/USD','JPY/USD', 'Location','Best');
figure(5);
data = squeeze(historical_zscores(2,:,:));
data = data';
plot(repmat(Dates,1,3),data(:,[2 4 5]));
legend('GPB/USD','EUR/USD','JPY/USD', 'Location','Best');
grid on;
xlim([xmin xmax]);
dateaxis('x',2,'02/04/2003');
title('Mean reversion of volatility');
xlabel('Vol cross-sectional Z-score');ylabel('value');
figure(6);
data = squeeze(historical_zscores(3,:,:));
data = data';
plot(repmat(Dates,1,3),data(:,[2 4 5]));
legend('GPB/USD','EUR/USD','JPY/USD', 'Location','Best');
grid on;
xlim([xmin xmax]);
dateaxis('x',2,'02/04/2003');
grid on;
xlabel('Skewness cross-sectional Z-score');ylabel('value');
