% x is column vector, missing data is NaN
function y = LinearInterpolate(x, lower, upper)
    n=length(x);
    if isnan(x(1))
        a=0;
    end
    
    for i=2:n
        if ~isnan(x(i)) && ~isnan(x(i-1))
            continue;
        elseif isnan(x(i)) && isnan(x(i-1)) && i<n
            continue;
        elseif isnan(x(i)) && isnan(x(i-1)) && i==n
            b=n+1;
            for j=a+1:b-1
                    x(j) = (upper-x(a))/(b-a)*(j-a)+x(a);
            end
        elseif isnan(x(i)) && ~isnan(x(i-1)) && i<n
           a =i-1; 
        elseif isnan(x(i)) && ~isnan(x(i-1)) && i==n
           x(i) = upper;
        elseif ~isnan(x(i)) && isnan(x(i-1))
           b=i;
           if a~=b && a~=0
               for j=a+1:b-1
                    x(j) = (x(b)-x(a))/(b-a)*(j-a)+x(a);
               end
           elseif a~=b && a==0
               for j=a+1:b-1 % assume x(0)=0
                    x(j) = (x(b)-lower)/(b-a)*(j-a)+lower;
               end               
           end
           a = 0;
        end
    end
    y = x;
end
