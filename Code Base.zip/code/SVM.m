% c --- penalty weight constant
% X --- signals, x = n by m matrix
% Y --- supervised data
function w_solve= SVM(X,Y,c)
%X=randn(6,2);
%Y= [1 -1 1 1 -1 1];

%Y=Y';
%c=1;
n = size(X,1);
m = size(X,2);
flag = 0;

% train svm using cvx
cvx_begin
    cvx_quiet(true);
    variables w(m) b xi(n)
    minimize 1/2*sum(w.*w) + c*sum(xi)
    Y.*(X*w + b) >= 1 - xi;
    xi >= 0;
cvx_end
if strcmp(cvx_status,'Solved')
    flag = 1;
end
w_solve= vertcat(w,b);
end

  