% Interprate results
clear; close all;
load('ccy_proj_results.mat');
load('removal_results.mat');
capital = 10^6;
% Read in data
vix = result_struct.VIX;
strat_returns = result_struct.strat_returns;
std_returns = result_struct.std_returns;
carry_returns = result_struct.carry_returns;
mom_returns = result_struct.mom_returns;
dates = result_struct.dates;
holdings = result_struct.holdings;
returns = result_struct.ccy_return ./ holdings;
months = 12;

strat_index = cumsum(strat_returns); strat_index = strat_index + 10^6;
mom_index = cumsum(mom_returns); mom_index = mom_index + 10^6;
std_index = cumsum(std_returns); std_index = std_index + 10^6;
carry_index = cumsum(carry_returns); carry_index = carry_index + 10^6;

% Plot the return against VIX index
%% Label the draw down
figure(100) 
[ax,h1,h2]=plotyy(dates,[strat_index;mom_index;std_index;carry_index],dates,vix);
set(h1,'LineWidth',2);
set(h2,'LineWidth',2);
set(h2,'LineStyle','--')
set(get(ax(1),'Ylabel'),'String','Strategies') ;
set(get(ax(2),'Ylabel'),'String','Vix') ;
%x = datestr(result_struct.dates,'mm/yyyy');
legend('Strategy','Momemtum','Volatility','Carry','VIX', 'Location','Best');
title('Compare the performances for different strategies');
xlim(ax(1),[dates(1),dates(end)+2]);
xlim(ax(2),[dates(1),dates(end)+2]);
dateaxis('x',2,datestr(731616));
xlabel('Dates');
xticklabel_rotate([],45);
set(ax(2),'xTick',[]);
corr_vix = corrcoef(strat_index,vix);
[ind, amount] = max_drawdown(strat_index);
hold off;

% Compare the maximum drawdowns for different strategies
[~,max_drawdown_strat] = max_drawdown(strat_index);
[~,max_drawdown_carry] = max_drawdown(carry_index);
[~,max_drawdown_mom] = max_drawdown(mom_index);
[~,max_drawdown_std] = max_drawdown(std_index);
figure(200)
drawdowns = [max_drawdown_strat max_drawdown_carry max_drawdown_mom max_drawdown_std];
max_drawdown_UBSV10 = 0.318;

hdl = bar(drawdowns,0.5);
grid on;
%legend('Strategy','Carry','Momentum','Volatility');
labels(1) = {'Optimal'};
labels(2) = {'Carry'};
labels(3) = {'Momentum'};
labels(4) = {'Volatility'};
set(hdl(1),'facecolor','green');
ylabel('$MM');
xticklabel_rotate([],45,labels);
title('Maximum draw down comparision');

% Demonstrate alpha
alpha = zeros(3,1);
beta = zeros(3,1);
stats = regstats(strat_returns' / capital, [mom_returns'/capital carry_returns'/capital std_returns'/capital],'linear');
alpha =stats.beta(1); beta = stats.beta(2:end); 
% coeff = regress(strat_index', [ones(length(carry_index),1) carry_index']);
% alpha(2) = coeff(1); beta(2) = coeff(2);
% coeff = regress(strat_index', [ones(length(carry_index),1) carry_index']);
% alpha(3) = coeff(1); beta(3) = coeff(2);
alpha
beta
%save('regressionresult.mat','stats');
t = strat_returns' / capital - ([mom_returns'/capital carry_returns'/capital std_returns'/capital])*beta;
t_stat = mean(t)/std(t)

mom_indexes = mom_returns >0;
carry_indexes = carry_returns < 0;
std_indexes = std_returns >0;
mom_returns
carry_returns
std_returns
intersect_indexes = intersect(mom_indexes,intersect(carry_indexes,std_indexes));
intersect_indexes
close all;
idx1 = find(mom_returns>0);
idx2  = find(std_returns>0);
idx5 = intersect(idx1,idx2);
coeff1 = regress(strat_returns(idx5)' / capital, [ mom_returns(idx5)'/capital std_returns(idx5)'/capital ]);

idx1 = find(mom_returns<0);
idx2  = find(std_returns<0);
idx6 = intersect(idx1,idx2);
coeff2 = regress(strat_returns(idx6)' / capital, [ mom_returns(idx6)'/capital std_returns(idx6)'/capital ]);

idx1 = find(mom_returns>0);
idx2  = find(std_returns<0);
idx7 = intersect(idx1,idx2);
coeff3 = regress(strat_returns(idx7)' / capital, [ mom_returns(idx7)'/capital std_returns(idx7)'/capital ]);

idx1 = find(mom_returns<0);
idx2  = find(std_returns>0);
idx8 = intersect(idx1,idx2);
coeff4 = regress(strat_returns(idx8)' / capital, [ mom_returns(idx8)'/capital std_returns(idx8)'/capital ]);


idx1 = find(mom_returns>0);
idx2  = find(carry_returns>0);
idx5 = intersect(idx1,idx2);
coeff1 = regress(strat_returns(idx5)' / capital, [ mom_returns(idx5)'/capital carry_returns(idx5)'/capital ]);

idx1 = find(mom_returns<0);
idx2  = find(carry_returns<0);
idx6 = intersect(idx1,idx2);
coeff2 = regress(strat_returns(idx6)' / capital, [ mom_returns(idx6)'/capital carry_returns(idx6)'/capital ]);

idx1 = find(mom_returns>0);
idx2  = find(carry_returns<0);
idx7 = intersect(idx1,idx2);
coeff3 = regress(strat_returns(idx7)' / capital, [ mom_returns(idx7)'/capital carry_returns(idx7)'/capital ]);

idx1 = find(mom_returns<0);
idx2  = find(carry_returns>0);
idx8 = intersect(idx1,idx2);
coeff4 = regress(strat_returns(idx8)' / capital, [ mom_returns(idx8)'/capital carry_returns(idx8)'/capital ]);

idx1 = find(std_returns>0);
idx2  = find(carry_returns>0);
idx5 = intersect(idx1,idx2);
coeff1 = regress(strat_returns(idx5)' / capital, [ std_returns(idx5)'/capital carry_returns(idx5)'/capital ]);

idx1 = find(std_returns<0);
idx2  = find(carry_returns<0);
idx6 = intersect(idx1,idx2);
coeff2 = regress(strat_returns(idx6)' / capital, [ std_returns(idx6)'/capital carry_returns(idx6)'/capital ]);

idx1 = find(std_returns>0);
idx2  = find(carry_returns<0);
idx7 = intersect(idx1,idx2);
coeff3 = regress(strat_returns(idx7)' / capital, [ std_returns(idx7)'/capital carry_returns(idx7)'/capital ]);

idx1 = find(std_returns<0);
idx2  = find(carry_returns>0);
idx8 = intersect(idx1,idx2);
coeff4 = regress(strat_returns(idx8)' / capital, [ std_returns(idx8)'/capital carry_returns(idx8)'/capital ]);

% Seperate liquid payoff from illiquid payoff
liquid_holding = holdings;
liquid_holding(1,:) = 0;
liquid_holding(3,:) = 0;
liquid_holding(6,:) = 0;
liquid_holding(7,:) = 0;
liquid_holding(8,:) = 0;
illiquid_holding = holdings - liquid_holding;
liquid_pnl = sum(liquid_holding .* returns,1) * capital;
cum_liq_pnl = cumsum(sum(liquid_holding .* returns,1)) * capital;
illiquid_pnl = sum(illiquid_holding .* returns,1) * capital;
cum_illiq_pnl = cumsum(sum(illiquid_holding .* returns,1)) * capital;
figure(250)
plot(dates,[cum_liq_pnl;cum_illiq_pnl;cumsum(strat_returns)],'LineWidth',3);
legend('liquid pnl','illiquid pnl','total', 'Location','best');
xlim([dates(1),dates(end)+2]);
title('Liquid P&L VS Illiquid P&L');
dateaxis('x',2,datestr(731616));
xticklabel_rotate([],45);
std(liquid_pnl)
std(illiquid_pnl)
std(strat_returns)
corrcoef(liquid_pnl,illiquid_pnl)
cum_liq_pnl(end) / sum(strat_returns)
cum_illiq_pnl(end) / sum(strat_returns)

% Test what would the performance be if missing of the currencies
indices = zeros(9,size(returns,2));
PnLs = removal_results.strat_return;
PnLs = PnLs(:,2:end);
vols = zeros(1,9);
indices = cumsum(PnLs,2) + capital;
for i = 1:9
   vols(i) = std(indices(i,:) / capital);
end
vol_strat = std(strat_index / capital);
figure(300)
hdl=plot(dates,indices(1,:),dates,indices(2:end,:),dates,strat_index,'LineWidth',1); 
lines = findobj(hdl, 'type', 'line'); 
set(lines(10),  'LineWidth',3,  'LineStyle','--')
gridLegend(hdl,3,{'AUD','GBP','CAD','EUR','JPY','NZD','NOK','SEK','CHF','Portfolio'},'location','North');
xlim([dates(1),dates(end)+2]);
dateaxis('x',2,datestr(731616));
xticklabel_rotate([],45);
title('Cumulative P&L');
figure(400)
ave_holdings = mean(holdings,2)
hld = bar(ave_holdings,0.7);
title('Average holdings for each currency');
xlabel = {'AUD','GBP','CAD','EUR','JPY','NZD','NOK','SEK','CHF'};
ylabel('%');
xticklabel_rotate([],45, xlabel);
set(hld,'facecolor','green');

figure(500)
IR = mean(strat_returns) / std(strat_returns) * sqrt(months);
IRs = zeros(1,9);
for i = 1:9
    IRs(i) = mean(PnLs(i,:)) ./ std(PnLs(i,:)) * sqrt(months);
end
%rets = [strat_index(end) / strat_index(1); indices(:,end) ./ indices(:,1)];
%hld = bar( (rets ./ [vol_strat vols]') / sqrt(size(returns,2) / 12),0.9);
hld = bar([IR IRs], 0.9);
title('IR comparison');
set(hld,'FaceColor','green');
labels = {'Portfolio','AUD','GBP','CAD','EUR','JPY','NZD','NOK','SEK','CHF'};
xticklabel_rotate([],45,labels);
% In sample IR, out of sample IR (yearly and cumulative)

