
clc;clear;
[num,txt,raw] = xlsread('Data Macro','PPI','A2:V130','basic');
datecolumn = num(:,19);
processed = zeros(length(datecolumn),11);
labels = {'Date' 'AUD' 'CAD' 'JPY' 'NZD' 'EUR/GRM' 'DKK' 'NOK' 'GBP' 'SEK' 'CHF' 'USD'};

% AUD
column=[1 2];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));

% CAD
column=[3 4];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));

% JPY
column=[5 6];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));



% NZD
column=[7 8];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));


% EUR/GRM
column=[9 10];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));


% DKK
column=[11 12];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));


% NOK
column=[13 14];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));


% GBP
column=[15 16];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));


% SEK
column=[17 18];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));
processed(2:end,column(2)/2) = processed(2:end,column(2)/2)-processed(1:end-1,column(2)/2);
processed(1,column(2)/2) = processed(2,column(2)/2);

% CHF
column=[19 20];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));

% USD
column=[21 22];
data = num(find(~isnan(num(:,column(2)))),column(2));
date = num(find(~isnan(num(:,column(1)))),column(1));
PPI = zeros(length(datecolumn),1);
PPI(:,1) = NaN;
for i=1:length(data)
    idx = find(datecolumn==date(i));
    PPI(idx) = data(i);
end
processed(:,column(2)/2) = LinearInterpolate(PPI,data(1),data(end));

xlswrite('PPIProcessed',labels,'PPIProcessed','A1');
%%xlswrite('PPIProcessed',datestr(datecolumn),'PPIProcessed','A2');
xlswrite('PPIProcessed',processed,'PPIProcessed','B2');

