
x = 0:0.01:20;
y1 = 200*exp(-0.05*x).*sin(x);
plot(x,y1);
axis([0 20 -200 200])
ax1=gca ;
ax2=axes('position',get(ax1,'position'),'yaxislocation','right','color','none');
axis([0 20 -10 10])